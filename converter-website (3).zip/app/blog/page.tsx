import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, User } from "lucide-react"

export const metadata = {
  title: "Calculator Guides & Tips Blog | ConvertEasy",
  description:
    "Learn how to use calculators effectively with our comprehensive guides on BMI, loan calculations, mortgage rates, unit conversions and more.",
}

const blogPosts = [
  {
    id: 1,
    title: "How to Calculate BMI: Complete Guide with Examples",
    excerpt:
      "Learn how to calculate your Body Mass Index (BMI) manually and understand what your BMI score means for your health.",
    category: "Health",
    readTime: "5 min read",
    date: "Dec 20, 2024",
    author: "Health Team",
    slug: "how-to-calculate-bmi-guide",
  },
  {
    id: 2,
    title: "Loan Calculator Guide: Understanding Monthly Payments",
    excerpt:
      "Master loan calculations with our step-by-step guide. Learn about interest rates, terms, and how to calculate total loan costs.",
    category: "Finance",
    readTime: "7 min read",
    date: "Dec 19, 2024",
    author: "Finance Team",
    slug: "loan-calculator-guide",
  },
  {
    id: 3,
    title: "Mortgage Calculator: How to Calculate Home Loan Payments",
    excerpt:
      "Everything you need to know about mortgage calculations, including principal, interest, taxes, and insurance (PITI).",
    category: "Finance",
    readTime: "8 min read",
    date: "Dec 18, 2024",
    author: "Finance Team",
    slug: "mortgage-calculator-guide",
  },
  {
    id: 4,
    title: "Tax Calculator 2024: Understanding Federal Income Tax",
    excerpt:
      "Navigate the 2024 tax brackets and learn how to calculate your federal income tax with our comprehensive guide.",
    category: "Finance",
    readTime: "6 min read",
    date: "Dec 17, 2024",
    author: "Tax Team",
    slug: "tax-calculator-2024-guide",
  },
  {
    id: 5,
    title: "Unit Conversion Made Easy: Metric vs Imperial",
    excerpt: "Master unit conversions with our complete guide to converting between metric and imperial measurements.",
    category: "Conversion",
    readTime: "4 min read",
    date: "Dec 16, 2024",
    author: "Conversion Team",
    slug: "unit-conversion-guide",
  },
  {
    id: 6,
    title: "Currency Converter: Understanding Exchange Rates",
    excerpt:
      "Learn how currency exchange rates work and how to get the best rates for your international transactions.",
    category: "Finance",
    readTime: "5 min read",
    date: "Dec 15, 2024",
    author: "Finance Team",
    slug: "currency-converter-guide",
  },
]

export default function Blog() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8">
          <Link href="/" className="text-blue-600 hover:text-blue-800 mb-4 inline-block">
            ← Back to Calculator Tools
          </Link>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Calculator Guides & Tips</h1>
          <p className="text-gray-600 text-lg">
            Learn how to use our calculators effectively with comprehensive guides, tips, and examples.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogPosts.map((post) => (
            <Card key={post.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="secondary">{post.category}</Badge>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    {post.readTime}
                  </div>
                </div>
                <CardTitle className="text-xl hover:text-blue-600">
                  <Link href={`/blog/${post.slug}`}>{post.title}</Link>
                </CardTitle>
                <CardDescription className="text-gray-600">{post.excerpt}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-1" />
                    {post.author}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {post.date}
                  </div>
                </div>
                <Link
                  href={`/blog/${post.slug}`}
                  className="inline-block mt-4 text-blue-600 hover:text-blue-800 font-medium"
                >
                  Read More →
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Card className="inline-block">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-2">Want to suggest a topic?</h2>
              <p className="text-gray-600 mb-4">Have a calculator or conversion topic you'd like us to cover?</p>
              <Link
                href="/contact"
                className="inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Contact Us
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
