"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calculator, DollarSign, Ruler, Thermometer, Hash, Activity, CreditCard, Home, Receipt } from "lucide-react"
import { SEOFooter } from "@/components/seo-footer"

export default function ConverterWebsite() {
  // Unit Converter State
  const [unitValue, setUnitValue] = useState("")
  const [unitFrom, setUnitFrom] = useState("meters")
  const [unitTo, setUnitTo] = useState("feet")
  const [unitResult, setUnitResult] = useState("")
  const [unitCategory, setUnitCategory] = useState("length")

  // Currency Converter State
  const [currencyValue, setCurrencyValue] = useState("")
  const [currencyFrom, setCurrencyFrom] = useState("USD")
  const [currencyTo, setCurrencyTo] = useState("EUR")
  const [currencyResult, setCurrencyResult] = useState("")

  // Temperature Converter State
  const [tempValue, setTempValue] = useState("")
  const [tempFrom, setTempFrom] = useState("celsius")
  const [tempTo, setTempTo] = useState("fahrenheit")
  const [tempResult, setTempResult] = useState("")

  // Number Base Converter State
  const [numberValue, setNumberValue] = useState("")
  const [numberFrom, setNumberFrom] = useState("decimal")
  const [numberTo, setNumberTo] = useState("binary")
  const [numberResult, setNumberResult] = useState("")

  // BMI Calculator State
  const [bmiWeight, setBmiWeight] = useState("")
  const [bmiHeight, setBmiHeight] = useState("")
  const [bmiUnit, setBmiUnit] = useState("metric")
  const [bmiResult, setBmiResult] = useState("")
  const [bmiCategory, setBmiCategory] = useState("")

  // Loan Calculator State
  const [loanAmount, setLoanAmount] = useState("")
  const [loanRate, setLoanRate] = useState("")
  const [loanTerm, setLoanTerm] = useState("")
  const [loanPayment, setLoanPayment] = useState("")
  const [loanTotal, setLoanTotal] = useState("")

  // Mortgage Calculator State
  const [mortgagePrice, setMortgagePrice] = useState("")
  const [mortgageDown, setMortgageDown] = useState("")
  const [mortgageRate, setMortgageRate] = useState("")
  const [mortgageTerm, setMortgageTerm] = useState("")
  const [mortgagePayment, setMortgagePayment] = useState("")
  const [mortgageTotal, setMortgageTotal] = useState("")

  // Tax Calculator State
  const [taxIncome, setTaxIncome] = useState("")
  const [taxStatus, setTaxStatus] = useState("single")
  const [taxResult, setTaxResult] = useState("")
  const [taxAfter, setTaxAfter] = useState("")

  // Conversion rates and formulas
  const unitConversions = {
    length: {
      meters: 1,
      feet: 3.28084,
      inches: 39.3701,
      centimeters: 100,
      kilometers: 0.001,
      miles: 0.000621371,
      yards: 1.09361,
    },
    weight: {
      kilograms: 1,
      pounds: 2.20462,
      ounces: 35.274,
      grams: 1000,
      stones: 0.157473,
      tons: 0.001,
    },
    volume: {
      liters: 1,
      gallons: 0.264172,
      quarts: 1.05669,
      pints: 2.11338,
      cups: 4.22675,
      milliliters: 1000,
      fluid_ounces: 33.814,
    },
  }

  const currencyRates = {
    USD: 1,
    EUR: 0.92,
    GBP: 0.79,
    JPY: 149.5,
    CAD: 1.36,
    AUD: 1.52,
    CHF: 0.88,
    CNY: 7.24,
  }

  // Unit Converter Logic
  useEffect(() => {
    if (unitValue && !isNaN(Number.parseFloat(unitValue))) {
      const value = Number.parseFloat(unitValue)
      const fromRate = unitConversions[unitCategory][unitFrom]
      const toRate = unitConversions[unitCategory][unitTo]
      const result = (value / fromRate) * toRate
      setUnitResult(result.toFixed(6).replace(/\.?0+$/, ""))
    } else {
      setUnitResult("")
    }
  }, [unitValue, unitFrom, unitTo, unitCategory])

  // Currency Converter Logic
  useEffect(() => {
    if (currencyValue && !isNaN(Number.parseFloat(currencyValue))) {
      const value = Number.parseFloat(currencyValue)
      const fromRate = currencyRates[currencyFrom]
      const toRate = currencyRates[currencyTo]
      const result = (value / fromRate) * toRate
      setCurrencyResult(result.toFixed(2))
    } else {
      setCurrencyResult("")
    }
  }, [currencyValue, currencyFrom, currencyTo])

  // Temperature Converter Logic
  useEffect(() => {
    if (tempValue && !isNaN(Number.parseFloat(tempValue))) {
      const value = Number.parseFloat(tempValue)
      let result = 0

      // Convert to Celsius first
      let celsius = value
      if (tempFrom === "fahrenheit") {
        celsius = ((value - 32) * 5) / 9
      } else if (tempFrom === "kelvin") {
        celsius = value - 273.15
      }

      // Convert from Celsius to target
      if (tempTo === "celsius") {
        result = celsius
      } else if (tempTo === "fahrenheit") {
        result = (celsius * 9) / 5 + 32
      } else if (tempTo === "kelvin") {
        result = celsius + 273.15
      }

      setTempResult(result.toFixed(2))
    } else {
      setTempResult("")
    }
  }, [tempValue, tempFrom, tempTo])

  // Number Base Converter Logic
  useEffect(() => {
    if (numberValue) {
      try {
        let decimal = 0

        // Convert to decimal first
        switch (numberFrom) {
          case "decimal":
            decimal = Number.parseInt(numberValue, 10)
            break
          case "binary":
            decimal = Number.parseInt(numberValue, 2)
            break
          case "hexadecimal":
            decimal = Number.parseInt(numberValue, 16)
            break
          case "octal":
            decimal = Number.parseInt(numberValue, 8)
            break
        }

        if (isNaN(decimal)) {
          setNumberResult("Invalid input")
          return
        }

        // Convert from decimal to target base
        let result = ""
        switch (numberTo) {
          case "decimal":
            result = decimal.toString(10)
            break
          case "binary":
            result = decimal.toString(2)
            break
          case "hexadecimal":
            result = decimal.toString(16).toUpperCase()
            break
          case "octal":
            result = decimal.toString(8)
            break
        }

        setNumberResult(result)
      } catch (error) {
        setNumberResult("Invalid input")
      }
    } else {
      setNumberResult("")
    }
  }, [numberValue, numberFrom, numberTo])

  // BMI Calculator Logic
  useEffect(() => {
    if (bmiWeight && bmiHeight && !isNaN(Number.parseFloat(bmiWeight)) && !isNaN(Number.parseFloat(bmiHeight))) {
      let weight = Number.parseFloat(bmiWeight)
      let height = Number.parseFloat(bmiHeight)

      // Convert to metric if needed
      if (bmiUnit === "imperial") {
        weight = weight * 0.453592 // lbs to kg
        height = height * 0.0254 // inches to meters
      } else {
        height = height / 100 // cm to meters
      }

      const bmi = weight / (height * height)
      setBmiResult(bmi.toFixed(1))

      // Determine category
      if (bmi < 18.5) setBmiCategory("Underweight")
      else if (bmi < 25) setBmiCategory("Normal weight")
      else if (bmi < 30) setBmiCategory("Overweight")
      else setBmiCategory("Obese")
    } else {
      setBmiResult("")
      setBmiCategory("")
    }
  }, [bmiWeight, bmiHeight, bmiUnit])

  // Loan Calculator Logic
  useEffect(() => {
    if (
      loanAmount &&
      loanRate &&
      loanTerm &&
      !isNaN(Number.parseFloat(loanAmount)) &&
      !isNaN(Number.parseFloat(loanRate)) &&
      !isNaN(Number.parseFloat(loanTerm))
    ) {
      const principal = Number.parseFloat(loanAmount)
      const monthlyRate = Number.parseFloat(loanRate) / 100 / 12
      const numPayments = Number.parseFloat(loanTerm) * 12

      const monthlyPayment =
        (principal * (monthlyRate * Math.pow(1 + monthlyRate, numPayments))) /
        (Math.pow(1 + monthlyRate, numPayments) - 1)

      const totalPayment = monthlyPayment * numPayments

      setLoanPayment(monthlyPayment.toFixed(2))
      setLoanTotal(totalPayment.toFixed(2))
    } else {
      setLoanPayment("")
      setLoanTotal("")
    }
  }, [loanAmount, loanRate, loanTerm])

  // Mortgage Calculator Logic
  useEffect(() => {
    if (
      mortgagePrice &&
      mortgageDown &&
      mortgageRate &&
      mortgageTerm &&
      !isNaN(Number.parseFloat(mortgagePrice)) &&
      !isNaN(Number.parseFloat(mortgageDown)) &&
      !isNaN(Number.parseFloat(mortgageRate)) &&
      !isNaN(Number.parseFloat(mortgageTerm))
    ) {
      const price = Number.parseFloat(mortgagePrice)
      const downPayment = Number.parseFloat(mortgageDown)
      const principal = price - downPayment
      const monthlyRate = Number.parseFloat(mortgageRate) / 100 / 12
      const numPayments = Number.parseFloat(mortgageTerm) * 12

      const monthlyPayment =
        (principal * (monthlyRate * Math.pow(1 + monthlyRate, numPayments))) /
        (Math.pow(1 + monthlyRate, numPayments) - 1)

      const totalPayment = monthlyPayment * numPayments

      setMortgagePayment(monthlyPayment.toFixed(2))
      setMortgageTotal(totalPayment.toFixed(2))
    } else {
      setMortgagePayment("")
      setMortgageTotal("")
    }
  }, [mortgagePrice, mortgageDown, mortgageRate, mortgageTerm])

  // Tax Calculator Logic
  useEffect(() => {
    if (taxIncome && !isNaN(Number.parseFloat(taxIncome))) {
      const income = Number.parseFloat(taxIncome)
      let tax = 0

      // Simplified US tax brackets for 2024 (single filer)
      const brackets =
        taxStatus === "single"
          ? [
              [0, 0.1],
              [11000, 0.12],
              [44725, 0.22],
              [95375, 0.24],
              [182050, 0.32],
              [231250, 0.35],
              [578125, 0.37],
            ]
          : [
              [0, 0.1],
              [22000, 0.12],
              [89450, 0.22],
              [190750, 0.24],
              [364200, 0.32],
              [462500, 0.35],
              [693750, 0.37],
            ]

      let remainingIncome = income

      for (let i = 0; i < brackets.length; i++) {
        const [threshold, rate] = brackets[i]
        const nextThreshold = i < brackets.length - 1 ? brackets[i + 1][0] : Number.POSITIVE_INFINITY

        if (remainingIncome > 0 && income > threshold) {
          const taxableAtThisBracket = Math.min(remainingIncome, nextThreshold - threshold)
          tax += taxableAtThisBracket * rate
          remainingIncome -= taxableAtThisBracket
        }
      }

      setTaxResult(tax.toFixed(2))
      setTaxAfter((income - tax).toFixed(2))
    } else {
      setTaxResult("")
      setTaxAfter("")
    }
  }, [taxIncome, taxStatus])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="mx-auto max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Free Online Calculator - BMI, Loan, Mortgage & Tax Calculator Tools
          </h1>
          <p className="text-gray-600 text-lg">
            Free calculators for BMI, loan payments, mortgage rates, tax calculations & unit conversions. Professional
            financial and health calculator tools.
          </p>
        </div>

        <Tabs defaultValue="units" className="w-full">
          <TabsList className="grid w-full grid-cols-8 mb-6">
            <TabsTrigger value="units" className="flex items-center gap-2">
              <Ruler className="h-4 w-4" />
              Units
            </TabsTrigger>
            <TabsTrigger value="currency" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Currency
            </TabsTrigger>
            <TabsTrigger value="temperature" className="flex items-center gap-2">
              <Thermometer className="h-4 w-4" />
              Temperature
            </TabsTrigger>
            <TabsTrigger value="numbers" className="flex items-center gap-2">
              <Hash className="h-4 w-4" />
              Numbers
            </TabsTrigger>
            <TabsTrigger value="bmi" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              BMI
            </TabsTrigger>
            <TabsTrigger value="loan" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Loan
            </TabsTrigger>
            <TabsTrigger value="mortgage" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              Mortgage
            </TabsTrigger>
            <TabsTrigger value="tax" className="flex items-center gap-2">
              <Receipt className="h-4 w-4" />
              Tax
            </TabsTrigger>
          </TabsList>

          <TabsContent value="units">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Unit Converter
                </CardTitle>
                <CardDescription>
                  Free unit converter calculator - Convert length, weight, volume measurements instantly. Meters to
                  feet, kg to lbs, liters to gallons & more.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-2">
                  <Label htmlFor="unit-category">Category</Label>
                  <Select value={unitCategory} onValueChange={setUnitCategory}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="length">Length</SelectItem>
                      <SelectItem value="weight">Weight</SelectItem>
                      <SelectItem value="volume">Volume</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="unit-from">From</Label>
                      <Select value={unitFrom} onValueChange={setUnitFrom}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.keys(unitConversions[unitCategory]).map((unit) => (
                            <SelectItem key={unit} value={unit}>
                              {unit.charAt(0).toUpperCase() + unit.slice(1).replace("_", " ")}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="unit-value">Value</Label>
                      <Input
                        id="unit-value"
                        type="number"
                        placeholder="Enter value"
                        value={unitValue}
                        onChange={(e) => setUnitValue(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="unit-to">To</Label>
                      <Select value={unitTo} onValueChange={setUnitTo}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.keys(unitConversions[unitCategory]).map((unit) => (
                            <SelectItem key={unit} value={unit}>
                              {unit.charAt(0).toUpperCase() + unit.slice(1).replace("_", " ")}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label>Result</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm">
                        {unitResult || "0"}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="currency">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Currency Converter
                </CardTitle>
                <CardDescription>
                  Live currency converter with exchange rates - Convert USD, EUR, GBP & major world currencies instantly
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="currency-from">From</Label>
                      <Select value={currencyFrom} onValueChange={setCurrencyFrom}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.keys(currencyRates).map((currency) => (
                            <SelectItem key={currency} value={currency}>
                              {currency}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="currency-value">Amount</Label>
                      <Input
                        id="currency-value"
                        type="number"
                        placeholder="Enter amount"
                        value={currencyValue}
                        onChange={(e) => setCurrencyValue(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="currency-to">To</Label>
                      <Select value={currencyTo} onValueChange={setCurrencyTo}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.keys(currencyRates).map((currency) => (
                            <SelectItem key={currency} value={currency}>
                              {currency}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label>Result</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm">
                        {currencyResult || "0.00"}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="temperature">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Thermometer className="h-5 w-5" />
                  Temperature Converter
                </CardTitle>
                <CardDescription>
                  Temperature conversion calculator - Convert Celsius to Fahrenheit, Kelvin instantly. Free online
                  temperature converter tool
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="temp-from">From</Label>
                      <Select value={tempFrom} onValueChange={setTempFrom}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="celsius">Celsius (°C)</SelectItem>
                          <SelectItem value="fahrenheit">Fahrenheit (°F)</SelectItem>
                          <SelectItem value="kelvin">Kelvin (K)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="temp-value">Temperature</Label>
                      <Input
                        id="temp-value"
                        type="number"
                        placeholder="Enter temperature"
                        value={tempValue}
                        onChange={(e) => setTempValue(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="temp-to">To</Label>
                      <Select value={tempTo} onValueChange={setTempTo}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="celsius">Celsius (°C)</SelectItem>
                          <SelectItem value="fahrenheit">Fahrenheit (°F)</SelectItem>
                          <SelectItem value="kelvin">Kelvin (K)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label>Result</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm">
                        {tempResult || "0.00"}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="numbers">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Hash className="h-5 w-5" />
                  Number Base Converter
                </CardTitle>
                <CardDescription>
                  Number base converter calculator - Convert decimal to binary, hex to decimal, octal conversions & more
                  number systems
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="number-from">From</Label>
                      <Select value={numberFrom} onValueChange={setNumberFrom}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="decimal">Decimal (Base 10)</SelectItem>
                          <SelectItem value="binary">Binary (Base 2)</SelectItem>
                          <SelectItem value="hexadecimal">Hexadecimal (Base 16)</SelectItem>
                          <SelectItem value="octal">Octal (Base 8)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="number-value">Number</Label>
                      <Input
                        id="number-value"
                        type="text"
                        placeholder="Enter number"
                        value={numberValue}
                        onChange={(e) => setNumberValue(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="number-to">To</Label>
                      <Select value={numberTo} onValueChange={setNumberTo}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="decimal">Decimal (Base 10)</SelectItem>
                          <SelectItem value="binary">Binary (Base 2)</SelectItem>
                          <SelectItem value="hexadecimal">Hexadecimal (Base 16)</SelectItem>
                          <SelectItem value="octal">Octal (Base 8)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label>Result</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm font-mono">
                        {numberResult || "0"}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bmi">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  BMI Calculator
                </CardTitle>
                <CardDescription>
                  Free BMI calculator - Calculate your Body Mass Index instantly. Check if you're underweight, normal,
                  overweight or obese
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid gap-2">
                    <Label>Unit System</Label>
                    <Select value={bmiUnit} onValueChange={setBmiUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="metric">Metric (kg, cm)</SelectItem>
                        <SelectItem value="imperial">Imperial (lbs, inches)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="grid gap-2">
                        <Label htmlFor="bmi-weight">Weight ({bmiUnit === "metric" ? "kg" : "lbs"})</Label>
                        <Input
                          id="bmi-weight"
                          type="number"
                          placeholder={`Enter weight in ${bmiUnit === "metric" ? "kg" : "lbs"}`}
                          value={bmiWeight}
                          onChange={(e) => setBmiWeight(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="bmi-height">Height ({bmiUnit === "metric" ? "cm" : "inches"})</Label>
                        <Input
                          id="bmi-height"
                          type="number"
                          placeholder={`Enter height in ${bmiUnit === "metric" ? "cm" : "inches"}`}
                          value={bmiHeight}
                          onChange={(e) => setBmiHeight(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="grid gap-2">
                        <Label>BMI Result</Label>
                        <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm font-semibold">
                          {bmiResult || "0.0"}
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <Label>Category</Label>
                        <div
                          className={`h-10 px-3 py-2 border border-input rounded-md flex items-center text-sm font-medium ${
                            bmiCategory === "Normal weight"
                              ? "bg-green-50 text-green-700"
                              : bmiCategory === "Underweight"
                                ? "bg-blue-50 text-blue-700"
                                : bmiCategory === "Overweight"
                                  ? "bg-yellow-50 text-yellow-700"
                                  : bmiCategory === "Obese"
                                    ? "bg-red-50 text-red-700"
                                    : "bg-background"
                          }`}
                        >
                          {bmiCategory || "Enter your details"}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="loan">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Loan Calculator
                </CardTitle>
                <CardDescription>
                  Free loan payment calculator - Calculate monthly payments, total interest & loan costs. Personal loan,
                  auto loan calculator
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="loan-amount">Loan Amount ($)</Label>
                      <Input
                        id="loan-amount"
                        type="number"
                        placeholder="Enter loan amount"
                        value={loanAmount}
                        onChange={(e) => setLoanAmount(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="loan-rate">Interest Rate (%)</Label>
                      <Input
                        id="loan-rate"
                        type="number"
                        step="0.01"
                        placeholder="Enter annual interest rate"
                        value={loanRate}
                        onChange={(e) => setLoanRate(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="loan-term">Loan Term (years)</Label>
                      <Input
                        id="loan-term"
                        type="number"
                        placeholder="Enter loan term in years"
                        value={loanTerm}
                        onChange={(e) => setLoanTerm(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label>Monthly Payment</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm font-semibold">
                        ${loanPayment || "0.00"}
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label>Total Payment</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm">
                        ${loanTotal || "0.00"}
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label>Total Interest</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm">
                        $
                        {loanTotal && loanAmount
                          ? (Number.parseFloat(loanTotal) - Number.parseFloat(loanAmount)).toFixed(2)
                          : "0.00"}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mortgage">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Home className="h-5 w-5" />
                  Mortgage Calculator
                </CardTitle>
                <CardDescription>
                  Free mortgage payment calculator - Calculate home loan payments, monthly mortgage costs & total
                  interest
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="mortgage-price">Home Price ($)</Label>
                      <Input
                        id="mortgage-price"
                        type="number"
                        placeholder="Enter home price"
                        value={mortgagePrice}
                        onChange={(e) => setMortgagePrice(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="mortgage-down">Down Payment ($)</Label>
                      <Input
                        id="mortgage-down"
                        type="number"
                        placeholder="Enter down payment"
                        value={mortgageDown}
                        onChange={(e) => setMortgageDown(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="mortgage-rate">Interest Rate (%)</Label>
                      <Input
                        id="mortgage-rate"
                        type="number"
                        step="0.01"
                        placeholder="Enter annual interest rate"
                        value={mortgageRate}
                        onChange={(e) => setMortgageRate(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="mortgage-term">Loan Term (years)</Label>
                      <Input
                        id="mortgage-term"
                        type="number"
                        placeholder="Enter loan term (usually 30)"
                        value={mortgageTerm}
                        onChange={(e) => setMortgageTerm(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label>Monthly Payment</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm font-semibold">
                        ${mortgagePayment || "0.00"}
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label>Loan Amount</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm">
                        $
                        {mortgagePrice && mortgageDown
                          ? (Number.parseFloat(mortgagePrice) - Number.parseFloat(mortgageDown)).toFixed(2)
                          : "0.00"}
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label>Total Interest</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm">
                        $
                        {mortgageTotal && mortgagePrice && mortgageDown
                          ? (
                              Number.parseFloat(mortgageTotal) -
                              (Number.parseFloat(mortgagePrice) - Number.parseFloat(mortgageDown))
                            ).toFixed(2)
                          : "0.00"}
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label>Total Payment</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm">
                        ${mortgageTotal || "0.00"}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tax">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Receipt className="h-5 w-5" />
                  Tax Calculator
                </CardTitle>
                <CardDescription>
                  Free income tax calculator - Calculate federal income tax, tax brackets & after-tax income for 2024
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="tax-income">Annual Income ($)</Label>
                      <Input
                        id="tax-income"
                        type="number"
                        placeholder="Enter your annual income"
                        value={taxIncome}
                        onChange={(e) => setTaxIncome(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label>Filing Status</Label>
                      <Select value={taxStatus} onValueChange={setTaxStatus}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="single">Single</SelectItem>
                          <SelectItem value="married">Married Filing Jointly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label>Federal Tax Owed</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm font-semibold">
                        ${taxResult || "0.00"}
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label>After-Tax Income</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-green-50 text-green-700 rounded-md flex items-center text-sm font-semibold">
                        ${taxAfter || "0.00"}
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label>Effective Tax Rate</Label>
                      <div className="h-10 px-3 py-2 border border-input bg-background rounded-md flex items-center text-sm">
                        {taxResult && taxIncome
                          ? ((Number.parseFloat(taxResult) / Number.parseFloat(taxIncome)) * 100).toFixed(2)
                          : "0.00"}
                        %
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-700">
                    <strong>Note:</strong> This calculator provides estimates based on 2024 federal tax brackets for
                    illustration purposes. Consult a tax professional for accurate tax planning.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <SEOFooter />
      </div>
    </div>
  )
}
