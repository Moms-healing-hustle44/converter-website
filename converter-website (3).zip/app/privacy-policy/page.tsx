import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

export const metadata = {
  title: "Privacy Policy | ConvertEasy - Free Online Calculator Tools",
  description:
    "Privacy Policy for ConvertEasy.com - Learn how we protect your data when using our free online calculators and conversion tools.",
}

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <Link href="/" className="text-blue-600 hover:text-blue-800 mb-4 inline-block">
            ← Back to Calculator Tools
          </Link>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Privacy Policy</h1>
          <p className="text-gray-600">Last updated: December 21, 2024</p>
        </div>

        <Card>
          <CardContent className="p-8 space-y-6">
            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Information We Collect</h2>
              <p className="text-gray-700 mb-4">
                ConvertEasy.com is committed to protecting your privacy. We collect minimal information to provide our
                free calculator and conversion services:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>
                  <strong>Usage Data:</strong> We use Google Analytics to understand how visitors use our calculators
                </li>
                <li>
                  <strong>Cookies:</strong> We use cookies for analytics and advertising purposes
                </li>
                <li>
                  <strong>Calculator Inputs:</strong> We do not store or save any numbers you enter into our calculators
                </li>
                <li>
                  <strong>Contact Information:</strong> Only if you contact us directly via our contact form
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">How We Use Your Information</h2>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>To provide and improve our calculator tools and services</li>
                <li>To analyze website usage and optimize user experience</li>
                <li>To display relevant advertisements through Google AdSense</li>
                <li>To respond to your inquiries and provide customer support</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Third-Party Services</h2>
              <p className="text-gray-700 mb-4">We use the following third-party services:</p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>
                  <strong>Google Analytics:</strong> For website analytics and user behavior tracking
                </li>
                <li>
                  <strong>Google AdSense:</strong> For displaying advertisements
                </li>
                <li>
                  <strong>Vercel:</strong> For website hosting and performance
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Data Security</h2>
              <p className="text-gray-700">
                We implement appropriate security measures to protect your information. All calculator computations are
                performed locally in your browser and are not transmitted to our servers.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Cookies Policy</h2>
              <p className="text-gray-700 mb-4">We use cookies to enhance your experience on our website:</p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>
                  <strong>Essential Cookies:</strong> Required for basic website functionality
                </li>
                <li>
                  <strong>Analytics Cookies:</strong> Help us understand how you use our calculators
                </li>
                <li>
                  <strong>Advertising Cookies:</strong> Used to display relevant ads
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Your Rights</h2>
              <p className="text-gray-700 mb-4">You have the right to:</p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>Access the personal information we hold about you</li>
                <li>Request correction of inaccurate information</li>
                <li>Request deletion of your personal information</li>
                <li>Opt-out of marketing communications</li>
                <li>Disable cookies in your browser settings</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Contact Us</h2>
              <p className="text-gray-700">
                If you have any questions about this Privacy Policy, please contact us at:
              </p>
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <p className="text-gray-700">
                  Email: privacy@converteasy.com
                  <br />
                  Website:{" "}
                  <Link href="/contact" className="text-blue-600 hover:text-blue-800">
                    Contact Form
                  </Link>
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Changes to This Policy</h2>
              <p className="text-gray-700">
                We may update this Privacy Policy from time to time. We will notify you of any changes by posting the
                new Privacy Policy on this page and updating the "Last updated" date.
              </p>
            </section>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
