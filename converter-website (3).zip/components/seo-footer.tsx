import Link from "next/link"

export function SEOFooter() {
  return (
    <footer className="bg-white border-t mt-12">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-6 gap-8">
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Unit Converters</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Length Converter
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Weight Converter
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Volume Converter
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Area Converter
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Financial Calculators</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Loan Calculator
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Mortgage Calculator
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Tax Calculator
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Interest Calculator
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Health Calculators</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <Link href="#" className="hover:text-blue-600">
                  BMI Calculator
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Body Fat Calculator
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Calorie Calculator
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Ideal Weight Calculator
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Currency Tools</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <Link href="#" className="hover:text-blue-600">
                  USD to EUR
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  GBP to USD
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Exchange Rates
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Currency Calculator
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Temperature</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Celsius to Fahrenheit
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Fahrenheit to Celsius
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Kelvin Converter
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Temperature Calculator
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Number Systems</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Binary Converter
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Hex Converter
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Decimal to Binary
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-600">
                  Base Calculator
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center">
          <p className="text-sm text-gray-600 mb-4">
            ConvertEasy.com - Free online calculators for BMI, loan payments, mortgage rates, tax calculations, unit
            conversions & more. Professional financial, health & conversion calculator tools for accurate results.
          </p>
          <p className="text-xs text-gray-500">
            © 2024 ConvertEasy. All rights reserved. |
            <Link href="/privacy-policy" className="hover:text-blue-600 ml-1">
              Privacy Policy
            </Link>{" "}
            |
            <Link href="/terms-of-service" className="hover:text-blue-600 ml-1">
              Terms of Service
            </Link>
          </p>
        </div>
      </div>
    </footer>
  )
}
