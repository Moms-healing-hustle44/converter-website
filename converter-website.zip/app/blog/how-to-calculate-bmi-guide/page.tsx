import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, User, ArrowLeft } from "lucide-react"

export const metadata = {
  title: "How to Calculate BMI: Complete Guide with Examples | ConvertEasy",
  description:
    "Learn how to calculate your Body Mass Index (BMI) manually and understand what your BMI score means for your health. Includes BMI formula, examples, and health categories.",
  keywords: "BMI calculator, body mass index, how to calculate BMI, BMI formula, healthy weight, BMI categories",
}

export default function BMIGuide() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <Link href="/blog" className="text-blue-600 hover:text-blue-800 mb-4 inline-flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Blog
          </Link>

          <div className="mb-4">
            <Badge variant="secondary" className="mb-2">
              Health
            </Badge>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              How to Calculate BMI: Complete Guide with Examples
            </h1>

            <div className="flex items-center gap-6 text-sm text-gray-500">
              <div className="flex items-center">
                <User className="h-4 w-4 mr-1" />
                Health Team
              </div>
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                December 20, 2024
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />5 min read
              </div>
            </div>
          </div>
        </div>

        <Card>
          <CardContent className="p-8 prose prose-lg max-w-none">
            <p className="text-xl text-gray-700 mb-6">
              Body Mass Index (BMI) is a simple calculation used to assess whether a person has a healthy body weight
              for their height. Learn how to calculate BMI manually and understand what your results mean.
            </p>

            <h2 className="text-2xl font-semibold text-gray-900 mb-4">What is BMI?</h2>
            <p className="text-gray-700 mb-6">
              BMI is a screening tool that indicates whether you are underweight, normal weight, overweight, or obese.
              While it's not a perfect measure of health, it's widely used by healthcare professionals as a quick
              assessment tool.
            </p>

            <h2 className="text-2xl font-semibold text-gray-900 mb-4">BMI Formula</h2>
            <div className="bg-blue-50 p-6 rounded-lg mb-6">
              <h3 className="font-semibold mb-2">Metric Formula:</h3>
              <p className="font-mono text-lg mb-4">BMI = weight (kg) ÷ height² (m²)</p>

              <h3 className="font-semibold mb-2">Imperial Formula:</h3>
              <p className="font-mono text-lg">BMI = (weight (lbs) ÷ height² (inches²)) × 703</p>
            </div>

            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Step-by-Step Calculation Examples</h2>

            <h3 className="text-xl font-semibold text-gray-800 mb-3">Example 1: Metric System</h3>
            <div className="bg-gray-50 p-4 rounded-lg mb-4">
              <p>
                <strong>Person:</strong> 70 kg, 175 cm tall
              </p>
              <p>
                <strong>Step 1:</strong> Convert height to meters: 175 cm = 1.75 m
              </p>
              <p>
                <strong>Step 2:</strong> Square the height: 1.75² = 3.06
              </p>
              <p>
                <strong>Step 3:</strong> Divide weight by height²: 70 ÷ 3.06 = 22.9
              </p>
              <p>
                <strong>Result:</strong> BMI = 22.9 (Normal weight)
              </p>
            </div>

            <h3 className="text-xl font-semibold text-gray-800 mb-3">Example 2: Imperial System</h3>
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <p>
                <strong>Person:</strong> 154 lbs, 5'7" (67 inches) tall
              </p>
              <p>
                <strong>Step 1:</strong> Square the height: 67² = 4,489
              </p>
              <p>
                <strong>Step 2:</strong> Divide weight by height²: 154 ÷ 4,489 = 0.0343
              </p>
              <p>
                <strong>Step 3:</strong> Multiply by 703: 0.0343 × 703 = 24.1
              </p>
              <p>
                <strong>Result:</strong> BMI = 24.1 (Normal weight)
              </p>
            </div>

            <h2 className="text-2xl font-semibold text-gray-900 mb-4">BMI Categories</h2>
            <div className="overflow-x-auto mb-6">
              <table className="w-full border-collapse border border-gray-300">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border border-gray-300 p-3 text-left">BMI Range</th>
                    <th className="border border-gray-300 p-3 text-left">Category</th>
                    <th className="border border-gray-300 p-3 text-left">Health Risk</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-gray-300 p-3">Below 18.5</td>
                    <td className="border border-gray-300 p-3">Underweight</td>
                    <td className="border border-gray-300 p-3">Increased risk</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-300 p-3">18.5 - 24.9</td>
                    <td className="border border-gray-300 p-3">Normal weight</td>
                    <td className="border border-gray-300 p-3">Lowest risk</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-300 p-3">25.0 - 29.9</td>
                    <td className="border border-gray-300 p-3">Overweight</td>
                    <td className="border border-gray-300 p-3">Increased risk</td>
                  </tr>
                  <tr>
                    <td className="border border-gray-300 p-3">30.0 and above</td>
                    <td className="border border-gray-300 p-3">Obese</td>
                    <td className="border border-gray-300 p-3">High risk</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Limitations of BMI</h2>
            <ul className="list-disc list-inside text-gray-700 space-y-2 mb-6">
              <li>Doesn't distinguish between muscle and fat mass</li>
              <li>May not be accurate for athletes with high muscle mass</li>
              <li>Doesn't account for bone density or body composition</li>
              <li>May not be suitable for elderly individuals</li>
              <li>Doesn't consider fat distribution</li>
            </ul>

            <h2 className="text-2xl font-semibold text-gray-900 mb-4">When to Consult a Healthcare Professional</h2>
            <p className="text-gray-700 mb-4">
              While BMI is a useful screening tool, it's important to consult with healthcare professionals for:
            </p>
            <ul className="list-disc list-inside text-gray-700 space-y-2 mb-6">
              <li>Comprehensive health assessments</li>
              <li>Weight management plans</li>
              <li>Understanding your individual health risks</li>
              <li>Addressing concerns about your BMI results</li>
            </ul>

            <div className="bg-blue-50 p-6 rounded-lg mb-6">
              <h3 className="font-semibold text-blue-900 mb-2">Try Our BMI Calculator</h3>
              <p className="text-blue-800 mb-4">
                Skip the manual calculations and use our free BMI calculator for instant results!
              </p>
              <Link
                href="/#bmi"
                className="inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Use BMI Calculator
              </Link>
            </div>

            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Conclusion</h2>
            <p className="text-gray-700">
              Calculating BMI is straightforward using the formulas provided above. Remember that BMI is just one
              indicator of health, and it's always best to consult with healthcare professionals for a complete health
              assessment. Use our free BMI calculator above for quick and accurate results.
            </p>
          </CardContent>
        </Card>

        <div className="mt-8">
          <Card>
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-4">Related Articles</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <Link
                  href="/blog/loan-calculator-guide"
                  className="block p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <h4 className="font-semibold text-gray-900">Loan Calculator Guide</h4>
                  <p className="text-sm text-gray-600">
                    Learn how to calculate loan payments and understand interest rates.
                  </p>
                </Link>
                <Link
                  href="/blog/unit-conversion-guide"
                  className="block p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <h4 className="font-semibold text-gray-900">Unit Conversion Guide</h4>
                  <p className="text-sm text-gray-600">
                    Master metric to imperial conversions with our comprehensive guide.
                  </p>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
