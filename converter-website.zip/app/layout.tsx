import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { Suspense } from "react"
import "./globals.css"
import { Analytics } from "@/components/analytics"

const ADSENSE_ID = process.env.NEXT_PUBLIC_ADSENSE_ID

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Free Online Calculator - BMI, Loan, Mortgage & Tax Calculator Tools | ConvertEasy",
  description:
    "Free online calculators for BMI, loan payments, mortgage rates, tax calculations & unit conversions. Professional financial, health & conversion calculator tools.",
  keywords:
    "BMI calculator, loan calculator, mortgage calculator, tax calculator, unit converter, currency converter, temperature converter, online calculator, conversion tool, free calculator, measurement converter, exchange rate, celsius fahrenheit, meters feet, kg pounds, body mass index, loan payment, mortgage payment, income tax",
  authors: [{ name: "ConvertEasy" }],
  creator: "ConvertEasy",
  publisher: "ConvertEasy",
  robots: "index, follow",
  openGraph: {
    title: "Free Online Converter - Unit, Currency & Temperature Calculator",
    description:
      "Convert units, currencies, temperatures & number bases instantly with our free online conversion tools.",
    url: "https://your-domain.com",
    siteName: "ConvertEasy",
    type: "website",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Free Online Converter Tools",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Free Online Converter - Unit, Currency & Temperature Calculator",
    description:
      "Convert units, currencies, temperatures & number bases instantly with our free online conversion tools.",
    images: ["/og-image.jpg"],
  },
  alternates: {
    canonical: "https://your-domain.com",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebApplication",
              name: "ConvertEasy - Free Online Converter",
              description: "Free online converter tools for units, currencies, temperatures and number bases",
              url: "https://your-domain.com",
              applicationCategory: "UtilityApplication",
              operatingSystem: "Any",
              offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "USD",
              },
              featureList: ["Unit Converter", "Currency Converter", "Temperature Converter", "Number Base Converter"],
            }),
          }}
        />
        {ADSENSE_ID && (
          <script
            async
            src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_ID}`}
            crossOrigin="anonymous"
          />
        )}
      </head>
      <body className={inter.className}>
        <Suspense fallback={<div>Loading...</div>}>
          {children}
          <Analytics />
        </Suspense>
      </body>
    </html>
  )
}
