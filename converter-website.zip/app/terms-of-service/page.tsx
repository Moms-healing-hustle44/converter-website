import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

export const metadata = {
  title: "Terms of Service | ConvertEasy - Free Online Calculator Tools",
  description:
    "Terms of Service for ConvertEasy.com - Rules and guidelines for using our free online calculators and conversion tools.",
}

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <Link href="/" className="text-blue-600 hover:text-blue-800 mb-4 inline-block">
            ← Back to Calculator Tools
          </Link>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Terms of Service</h1>
          <p className="text-gray-600">Last updated: December 21, 2024</p>
        </div>

        <Card>
          <CardContent className="p-8 space-y-6">
            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Acceptance of Terms</h2>
              <p className="text-gray-700">
                By accessing and using ConvertEasy.com, you accept and agree to be bound by the terms and provision of
                this agreement. If you do not agree to abide by the above, please do not use this service.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Description of Service</h2>
              <p className="text-gray-700 mb-4">
                ConvertEasy.com provides free online calculator and conversion tools including:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>Unit conversion calculators (length, weight, volume, temperature)</li>
                <li>Financial calculators (loan, mortgage, tax calculations)</li>
                <li>Health calculators (BMI calculator)</li>
                <li>Currency conversion tools</li>
                <li>Number base conversion tools</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Use License</h2>
              <p className="text-gray-700 mb-4">
                Permission is granted to temporarily use ConvertEasy.com for personal, non-commercial transitory viewing
                only. This is the grant of a license, not a transfer of title, and under this license you may not:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>Modify or copy the materials</li>
                <li>Use the materials for any commercial purpose or for any public display</li>
                <li>Attempt to reverse engineer any software contained on the website</li>
                <li>Remove any copyright or other proprietary notations from the materials</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Disclaimer</h2>
              <p className="text-gray-700 mb-4">
                The information and calculators on ConvertEasy.com are provided on an 'as is' basis. To the fullest
                extent permitted by law, this Company:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>Excludes all representations and warranties relating to this website and its contents</li>
                <li>Does not guarantee the accuracy of calculations or conversions</li>
                <li>Recommends consulting professionals for important financial or health decisions</li>
                <li>Is not liable for any damages arising from the use of our calculators</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Accuracy of Materials</h2>
              <p className="text-gray-700">
                The materials appearing on ConvertEasy.com could include technical, typographical, or photographic
                errors. We do not warrant that any of the materials on its website are accurate, complete, or current.
                We may make changes to the materials contained on its website at any time without notice.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Financial Disclaimer</h2>
              <p className="text-gray-700">
                Our financial calculators (loan, mortgage, tax) provide estimates for educational purposes only. Actual
                rates, terms, and calculations may vary. Always consult with qualified financial professionals before
                making important financial decisions.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Health Disclaimer</h2>
              <p className="text-gray-700">
                Our health calculators (BMI) are for informational purposes only and should not replace professional
                medical advice. Always consult with healthcare professionals for medical decisions.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Prohibited Uses</h2>
              <p className="text-gray-700 mb-4">You may not use our service:</p>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>For any unlawful purpose or to solicit others to perform unlawful acts</li>
                <li>
                  To violate any international, federal, provincial, or state regulations, rules, laws, or local
                  ordinances
                </li>
                <li>
                  To infringe upon or violate our intellectual property rights or the intellectual property rights of
                  others
                </li>
                <li>To harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate</li>
                <li>To submit false or misleading information</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Governing Law</h2>
              <p className="text-gray-700">
                These terms and conditions are governed by and construed in accordance with the laws of the United
                States and you irrevocably submit to the exclusive jurisdiction of the courts in that state or location.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Contact Information</h2>
              <p className="text-gray-700">
                If you have any questions about these Terms of Service, please contact us at:
              </p>
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <p className="text-gray-700">
                  Email: legal@converteasy.com
                  <br />
                  Website:{" "}
                  <Link href="/contact" className="text-blue-600 hover:text-blue-800">
                    Contact Form
                  </Link>
                </p>
              </div>
            </section>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
